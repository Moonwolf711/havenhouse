import { addDays, startOfMonth, endOfMonth, isAfter } from 'date-fns'
import type { Lease } from '@prisma/client'

export function currentMonthBounds(now = new Date()) { return { start: startOfMonth(now), end: endOfMonth(now) } }
export function isPastDue(lease: Lease, now = new Date()) { const lateEdge = new Date(now.getFullYear(), now.getMonth(), lease.graceThroughDay); return isAfter(now, lateEdge) }
export function computeLateFees(policy: { type: string, amount: number } | null, lease: Lease, totalPaidThisMonth: number, now = new Date()) {
  if (!policy) return 0
  const lateEdge = new Date(now.getFullYear(), now.getMonth(), lease.graceThroughDay)
  if (!isAfter(now, lateEdge)) return 0
  if (policy.type === 'FLAT') return policy.amount
  const daysLate = Math.max(0, Math.floor((+now - +addDays(lateEdge, 1)) / 86_400_000) + 1)
  return Math.max(0, daysLate * policy.amount)
}
