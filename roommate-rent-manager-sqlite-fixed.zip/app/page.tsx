import { prisma } from '@/lib/db'
import { currentMonthBounds, computeLateFees, isPastDue } from '@/lib/rent'
export const runtime = 'nodejs'
export default async function Page() {
  const now = new Date()
  const { start, end } = currentMonthBounds(now)
  const lease = await prisma.lease.findFirst({ include: { lateFeePolicy: true } })
  if (!lease) return <div>No lease found. Run seeds.</div>
  const payments = await prisma.payment.findMany({ where: { status: 'SUCCEEDED', createdAt: { gte: start, lte: end } } })
  const expenses = await prisma.expense.findMany({ where: { createdAt: { gte: start, lte: end } } })
  const totalPaid = payments.reduce((s,p)=>s+p.amount,0)
  const lateFees = computeLateFees(lease.lateFeePolicy, lease, totalPaid, now)
  const status = isPastDue(lease, now) ? 'Past Due' : totalPaid >= lease.rent ? 'All Set' : 'Due Soon'
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Sandbox Fixed</h1>
      <div>Status: {status}</div>
      <div>Rent: ${(lease.rent/100).toFixed(2)}</div>
      <div>Paid: ${(totalPaid/100).toFixed(2)}</div>
      <div>Late fees: ${(lateFees/100).toFixed(2)}</div>
      <div>Remaining: ${((lease.rent+lateFees-totalPaid)/100).toFixed(2)}</div>
      <div className="text-sm text-gray-500">This build fixes Prisma enum & relations for SQLite.</div>
    </div>
  )
}
