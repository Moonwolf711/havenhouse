import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  const household = await prisma.household.upsert({
    where: { id: 'household_1' },
    update: {},
    create: { id: 'household_1', name: 'Maple St. • Unit A' },
  })

  const lease = await prisma.lease.create({
    data: {
      householdId: household.id,
      rent: 240000,
      dueDay: 1,
      graceThroughDay: 5,
      allocationMethod: 'EQUAL',
      startAt: new Date('2025-06-01'),
      endAt: new Date('2026-05-31'),
    }
  })

  await prisma.lateFeePolicy.create({
    data: { leaseId: lease.id, type: 'FLAT', amount: 6000 }
  })

  const members = await prisma.leaseMember.createMany({
    data: [
      { leaseId: lease.id, name: 'Tyler' },
      { leaseId: lease.id, name: 'Alex' },
      { leaseId: lease.id, name: 'Sam' },
    ]
  })

  const now = new Date()
  await prisma.payment.createMany({
    data: [
      { householdId: household.id, amount: 90000, payerName: 'Alex', method: 'manual', status: 'SUCCEEDED', createdAt: new Date(now.getFullYear(), now.getMonth(), 1) },
      { householdId: household.id, amount: 85000, payerName: 'Tyler', method: 'manual', status: 'SUCCEEDED', createdAt: new Date(now.getFullYear(), now.getMonth(), 3) }
    ]
  })
  await prisma.expense.create({
    data: { householdId: household.id, amount: 9000, label: 'Internet', createdAt: new Date(now.getFullYear(), now.getMonth(), 2) }
  })
}

main().then(()=>process.exit(0)).catch(e=>{console.error(e);process.exit(1)})
